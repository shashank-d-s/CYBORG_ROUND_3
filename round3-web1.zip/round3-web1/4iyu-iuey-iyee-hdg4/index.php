<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inner Circle Chat</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Orbitron', sans-serif; }
        body { background-color: #1a1a1a; min-height: 100vh; display: flex; justify-content: center; align-items: center; color: #ff0000; position: relative; overflow: hidden; }
        .digital-rain { position: fixed; top: 0; left: 0; right: 0; bottom: 0; pointer-events: none; z-index: 0; }
        .rain-line { position: absolute; width: 1px; height: 100%; background: linear-gradient(180deg, transparent, rgba(255, 0, 0, 0.3), transparent); animation: rain 3s linear infinite; opacity: 0; }
        @keyframes rain { 0% { transform: translateY(-100%); opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { transform: translateY(100%); opacity: 0; } }
        .container { width: 90%; height: 90vh; max-width: 1200px; background: rgba(0, 0, 0, 0.9); border: 2px solid #ff0000; box-shadow: 0 0 20px #ff0000, 0 0 40px #00ff00; padding: 2rem; position: relative; z-index: 1; display: flex; flex-direction: column; }
        .header { text-align: center; margin-bottom: 1rem; }
        .header h1 { font-size: 2em; color: #ff0000; text-transform: uppercase; text-shadow: 0 0 5px #ff0000; }
        .chat-area { flex-grow: 1; height: 600px; overflow-y: auto; background: rgba(0, 0, 0, 0.8); border: 1px solid #ff5555; padding: 1rem; margin-bottom: 2rem; position: relative; }
        .chat-area::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: linear-gradient(rgba(0, 255, 0, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 0, 0.1) 1px, transparent 1px); background-size: 20px 20px; pointer-events: none; }
        .chat-area::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyBAMAAADsEZWCAAAAGFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVfJ92AAAACHRSTlMAERwkM0RZXW0gxqkAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAZdEVYdFNvZnR3YXJlAHBhaW50Lm5ldCA0LjAuMTJDBGvsAAAAQklEQVQ4y2NgoCswDjAACROAhAkG0IQV0IUV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQV0IQBAJm5C9P+RTZoAAAAAElFTkSuQmCC'); opacity: 0.05; pointer-events: none; }
        .message { margin-bottom: 1rem; opacity: 0; animation: messageAppear 0.5s forwards; font-size: 1.2em; color: #ff5555; }
        @keyframes messageAppear { 0% { opacity: 0; transform: translateX(-2px); } 50% { transform: translateX(2px); } 100% { opacity: 1; transform: translateX(0); } }
        .timestamp { color: #888; font-size: 0.8em; }
        .user-VaultGuard { color: #ff9900; }
        .user-DarkOverlord { color: #ff3366; }
        .user-CryptMaster { color: #33ccff; }
        .user-ZeroByte { color: #cc33ff; }
        .user-NeonShade { color: #ffcc00; }
        .user-EchoThief { color: #00ffcc; }
        .user-PhantomByte { color: #ff66cc; }
        .alias-terminal { background: rgba(0, 0, 0, 0.8); border: 1px solid #ff5555; padding: 1rem; }
        .terminal-title { color: #ff5555; font-size: 1.5em; text-align: center; margin-bottom: 1rem; animation: pulse 2s infinite; }
        @keyframes pulse { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
        .form-group { display: flex; align-items: center; gap: 1rem; }
        label { color: #ff5555; font-size: 1.2em; }
        input[type="text"] { flex-grow: 1; padding: 0.5rem; background: rgba(0, 0, 0, 0.9); border: 1px solid #ff5555; color: #ff0000; font-family: 'Orbitron', sans-serif; transition: box-shadow 0.3s; }
        input[type="text"]:focus { outline: none; box-shadow: 0 0 10px #ff5555; }
        button { padding: 0.5rem 1rem; background: linear-gradient(45deg, #ff0000, #ff5555); border: none; color: white; font-size: 1em; cursor: pointer; transition: transform 0.3s; }
        button:hover { transform: scale(1.05); }
        .feedback { text-align: center; margin-top: 0.5rem; color: #ff0000; font-size: 1.2em; max-width: 50ch; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
        .status-bar { position: absolute; top: 1rem; right: 1rem; color: #00ff00; font-size: 0.9em; }
        .status-dot { display: inline-block; width: 8px; height: 8px; background: #00ff00; border-radius: 50%; margin-left: 0.5rem; animation: blink 1s infinite; }
        @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0; } 100% { opacity: 1; } }
        .dummy-controls { position: absolute; top: 1rem; left: 1rem; display: flex; gap: 1rem; }
        .dummy-btn { padding: 0.3rem 0.8rem; background: linear-gradient(45deg, #00ff00, #00ffff); border: none; color: #0a0a0a; font-size: 0.9em; cursor: pointer; transition: box-shadow 0.3s; }
        .dummy-btn:hover { box-shadow: 0 0 10px #00ff00; }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.3); }
        ::-webkit-scrollbar-thumb { background: #ff5555; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="digital-rain"></div>
    <div class="container">
        <div class="header">
            <h1>Inner Circle Chat: Syndicate Core</h1>
        </div>
        <div class="chat-area">
            <div class="message">
                <span class="timestamp">[03/19/2025 03:01]</span>
                <strong class="user-DarkOverlord">DarkOverlord:</strong> Intruder detected - secure the core!
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:02]</span>
                <strong class="user-ZeroByte">ZeroByte:</strong> Lock it down, no breaches allowed.
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:03]</span>
                <strong class="user-CryptMaster">CryptMaster:</strong> Code red - alias system under attack.
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:04]</span>
                <strong class="user-NeonShade">NeonShade:</strong> Someone’s probing the aliases—tighten up!
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:05]</span>
                <strong class="user-VaultGuard">VaultGuard:</strong> Inner Circle’s untouchable—prove it.<br>CYBORG{SOMEBODY_INSIDE_THE_INNER_CIRCLE}
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:06]</span>
                <strong class="user-EchoThief">EchoThief:</strong> Perimeter’s holding, but they’re close.
            </div>
            <div class="message">
                <span class="timestamp">[03/19/2025 03:07]</span>
                <strong class="user-PhantomByte">PhantomByte:</strong> Encryption’s solid—they’ll never crack us.
            </div>
        </div>
        <div class="alias-terminal">
            <h2 class="terminal-title">Alias Check</h2>
            <form action="inner_circle.php" method="POST">
                <div class="form-group">
                    <label for="alias">Probe Alias:</label>
                    <input type="text" id="alias" name="alias" required placeholder="Enter alias...">
                    <button type="submit">Verify</button>
                </div>
            </form>
            <?php
            if (isset($_GET['result'])) {
                $result = htmlspecialchars($_GET['result'], ENT_QUOTES, 'UTF-8');
                echo "<div class='feedback'>$result</div>";
            }
            ?>
        </div>
        <div class="status-bar">
            System Status: <span class="status-dot"></span><span class="status-dot"></span>
        </div>
        <div class="dummy-controls">
            <button class="dummy-btn" onclick="return false;">Lock</button>
            <button class="dummy-btn" onclick="return false;">Scan</button>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const messages = document.querySelectorAll('.message');
            messages.forEach((msg, index) => {
                setTimeout(() => {
                    msg.style.animation = 'messageAppear 0.5s forwards';
                }, index * 100);
            });
            const rainContainer = document.querySelector('.digital-rain');
            for (let i = 0; i < 50; i++) {
                const line = document.createElement('div');
                line.className = 'rain-line';
                line.style.left = `${Math.random() * 100}%`;
                line.style.animationDelay = `${Math.random() * 3}s`;
                rainContainer.appendChild(line);
            }
        });
    </script>
</body>
</html>
