<?php
// Connect to SQLite database
$db = new SQLite3('level4.db');

// Check if form was submitted
if (isset($_POST['alias'])) {
    // Get the raw input from the form
    $input = $_POST['alias'];

    // Filter only semicolon, keep it injectable but single-statement
    $input = str_replace(";", "", $input);

    // Vulnerable query with added complexity
    $query = "SELECT h4ck3r_n4m3 || '-' || CAST(RANDOM() AS TEXT) AS h4ck3r_n4m3 FROM inner_circle_hackers WHERE h4ck3r_n4m3 = '$input' LIMIT 1";
    
    // Execute the query with error handling
    $result = $db->query($query);
    
    if ($result) {
        $row = $result->fetchArray(SQLITE3_ASSOC);
        if ($row) {
            $output = $row['h4ck3r_n4m3']; // UNION results with noise
        } else {
            $output = "No match found";
            usleep(500000); // 0.5s delay on failure to slow brute-forcing
        }
    } else {
        $output = "Query failed - check your syntax";
        usleep(500000); // 0.5s delay on error
    }
    
    // Close the database connection
    $db->close();
    
    // Redirect back to index.php with the result
    header("Location: index.php?result=" . urlencode($output));
    exit();
} else {
    // If no POST data, redirect back to index.php
    header("Location: index.php");
    exit();
}
?>
