<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input_1 = $_POST["input1"] ? $_POST["input1"] : "";
    $input_2 = $_POST["input2"] ? $_POST["input2"] : "";
    sleep(1);

    if ($input_1 != "" && $input_2 != "") {
        if (strlen($input_1) < 6 && strlen($input_1)>4) {
            if ($input_1 < "8" && $input_1 < "7.C4A" && $input_1 > "7.98A") {
                if (strlen($input_2) < 7 && strlen($input_2) > 5) {
                    if ($input_2 <"4.CzbA"  && $input_2 > "4.4CZ9") {
                        header("Location: auth_2fa.php");
                        exit();
                    } else {
                        header("Location: security.html");
                        exit();
                    }
                } else {
                    header("Location: security.html");
                        exit();
                }
            } else {
                header("Location: security.html");
                        exit();
            }
        } else {
            header("Location: security.html");
                        exit();
        }
    } else {
        header("Location: security.html");
                        exit();
    }
}
?>
