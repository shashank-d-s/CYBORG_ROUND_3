<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $key1 = $_POST["key1"] ? $_POST["key1"] : "";
    $key2 = $_POST["key2"] ? $_POST["key2"] : "";

    if ($key1 != "" && $key2 != "") {
        if (md5($key1) == md5($key2) && $key1 !== $key2) {
            header("Location: /4iyu-iuey-iyee-hdg4");
            exit();
        } else {
            $message = "<br><br><br><h4>Authentication failed.</h4>";
        }
    } else {
        $message = "<br><br><br><h4>Enter both keys.</h4>";
    }
}

$flag = "CYBORG{PHASE_1_PASSED_SUCCESS}"; // The flag to display, adjust if different
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Crew: 2FA Breach</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Orbitron', sans-serif;
        }
        body {
            background-color: #1a1a1a;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #00ff00;
            position: relative;
            overflow: hidden;
        }
        .digital-rain {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            pointer-events: none;
            z-index: 0;
        }
        .rain-line {
            position: absolute;
            width: 1px;
            height: 100%;
            background: linear-gradient(180deg, transparent, rgba(0, 255, 0, 0.3), transparent);
            animation: rain 3s linear infinite;
            opacity: 0;
        }
        @keyframes rain {
            0% { transform: translateY(-100%); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(100%); opacity: 0; }
        }
        .security-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            filter: blur(4px);
            pointer-events: none;
        }
        .security-bg::before {
            content: "[03/17/2025 01:04] <ShadowHack> 2FA protocols engaged\n" 
                    "[03/17/2025 01:05] <EchoThief> Key verification in progress\n" 
                    "[03/17/2025 01:06] <PhantomByte> Access pending approval\n" 
                    "[03/17/2025 01:07] <VaultGuard> Breach alert triggered\n" 
                    "[03/17/2025 01:08] <NetRunner> Secondary auth required\n" 
                    "[03/17/2025 01:09] <CipherQueen> Systems on high alert\n" 
                    "[03/17/2025 01:10] <SystemGhost> Key collision detected\n" 
                    "[03/17/2025 01:11] <DataPhantom> Inner Circle locked\n" 
                    "[03/17/2025 01:12] <CodeSlicer> Authentication logs updated\n" 
                    "[03/17/2025 01:13] <ByteBlaster> Security sweep initiated\n" 
                    "[03/17/2025 01:14] <GhostPulse> 2FA timeout enforced\n" 
                    "[03/17/2025 01:15] <NeonShade> Access gates reinforced";
            white-space: pre;
            color: rgba(0, 255, 0, 0.4);
            font-size: 1em;
            position: absolute;
            top: 5%;
            left: 10%;
            text-shadow: 0 0 5px rgba(0, 255, 0, 0.2);
        }
        .container {
            width: 90%;
            max-width: 1200px;
            background: rgba(0, 0, 0, 0.9);
            border: 2px solid #00ff00;
            box-shadow: 0 0 20px #00ff00, 0 0 40px #00ffff;
            padding: 2rem;
            position: relative;
            z-index: 1;
        }
        .header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .header h1 {
            font-size: 2em;
            color: #00ff00;
            text-transform: uppercase;
            text-shadow: 0 0 5px #00ff00;
        }
        .header p {
            color: #ff0000;
            font-size: 1.2em;
        }
        .security-terminal {
            background: rgba(0, 0, 0, 0.8);
            border: 1px solid #00ffff;
            padding: 2rem;
        }
        /* In the realm of cryptographic puzzles, sometimes two different paths lead to the same destination. While inputs are meant to be unique fingerprints, history has shown that not all fingerprints are truly distinct. Some keys may unlock doors in unexpected ways, yet not all doors require a perfect match—sometimes, a mere resemblance is enough. But beware, as appearances can be deceiving, and true security lies beyond just one-way functions */
        .terminal-title {
            color: #00ffff;
            font-size: 1.5em;
            text-align: center;
            margin-bottom: 1.5rem;
            text-shadow: 0 0 5px #00ffff;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #00ffff;
        }
        input[type="text"] {
            width: 100%;
            padding: 0.8rem;
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #00ffff;
            color: #00ff00;
            font-family: 'Orbitron', sans-serif;
            transition: box-shadow 0.3s;
        }
        input[type="text"]:focus {
            outline: none;
            box-shadow: 0 0 15px #00ffff;
        }
        button {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(45deg, #ff0000, #00ff00);
            border: none;
            color: white;
            font-family: 'Orbitron', sans-serif;
            font-size: 1.2em;
            cursor: pointer;
            transition: transform 0.3s;
        }
        button:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="digital-rain"></div>
    <div class="security-bg"></div>
    <div class="container">
        <div class="header">
            <h1>Security Crew: 2FA Breach</h1>
            <p>Enter the Keys to Proceed</p>
        </div>
        <div class="security-terminal">
            <h2 class="terminal-title">Phase 2: Two-Factor Authentication</h2>
            <div class="form-group">
                <label>Flag:</label>
                <pre style="color: #00ff00; background: rgba(0, 0, 0, 0.8); padding: 1rem; border: 1px solid #00ffff;"><?php echo htmlspecialchars($flag); ?></pre>
            </div>
            <form action="auth_2fa.php" method="POST">
                <div class="form-group">
                    <label for="key1">Key 1:</label>
                    <input type="text" id="key1" name="key1" required placeholder="First key...">
                </div>
                <div class="form-group">
                    <label for="key2">Key 2:</label>
                    <input type="text" id="key2" name="key2" required placeholder="Second key...">
                </div>
                <button type="submit">Authenticate</button>
            </form>
            <?php if (isset($message)) echo $message; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const rainContainer = document.querySelector('.digital-rain');
            const numberOfLines = 50;
            for (let i = 0; i < numberOfLines; i++) {
                const line = document.createElement('div');
                line.className = 'rain-line';
                line.style.left = `${Math.random() * 100}%`;
                line.style.animationDelay = `${Math.random() * 3}s`;
                rainContainer.appendChild(line);
            }
        });
    </script>
</body>
</html>
