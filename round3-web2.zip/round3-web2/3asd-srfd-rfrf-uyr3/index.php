<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Crew Chat</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Orbitron', sans-serif; }
        body { background-color: #1a1a1a; min-height: 100vh; display: flex; justify-content: center; align-items: center; color: #00ff00; position: relative; overflow: hidden; }
        .digital-rain { position: fixed; top: 0; left: 0; right: 0; bottom: 0; pointer-events: none; z-index: 0; }
        .rain-line { position: absolute; width: 1px; height: 100%; background: linear-gradient(180deg, transparent, rgba(0, 255, 0, 0.3), transparent); animation: rain 3s linear infinite; opacity: 0; }
        @keyframes rain { 0% { transform: translateY(-100%); opacity: 0; } 10% { opacity: 1; } 90% { opacity: 1; } 100% { transform: translateY(100%); opacity: 0; } }
        .security-bg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; filter: blur(4px); pointer-events: none; }
        .security-bg::before { content: "[03/17/2025 00:55] <VaultGuard> Perimeter scans initiated\n[03/17/2025 00:56] <NetRunner> Firewall reinforced\n[03/17/2025 00:57] <SystemGhost> Suspicious activity flagged\n[03/17/2025 00:58] <CipherQueen> Encryption keys rotated\n[03/17/2025 00:59] <ShadowHack> Monitoring all channels\n[03/17/2025 01:00] <EchoThief> Access logs scrubbed\n[03/17/2025 01:01] <VaultGuard> Lockdown active\n[03/17/2025 01:02] <PhantomByte> Intrusion countermeasures deployed\n[03/17/2025 01:03] <DataPhantom> Secure channels only\n[03/17/2025 01:04] <CodeSlicer> Network traffic rerouted\n[03/17/2025 01:05] <ByteBlaster> Perimeter breach attempt logged\n[03/17/2025 01:06] <GhostPulse> System integrity verified\n[03/17/2025 01:07] <NeonShade> Unauthorized packets dropped"; white-space: pre; color: rgba(0, 255, 0, 0.4); font-size: 1em; position: absolute; top: 5%; left: 10%; text-shadow: 0 0 5px rgba(0, 255, 0, 0.2); }
        .container { width: 90%; max-width: 1200px; background: rgba(0, 0, 0, 0.9); border: 2px solid #00ff00; box-shadow: 0 0 20px #00ff00, 0 0 40px #00ffff; padding: 2rem; position: relative; z-index: 1; }
        .header { text-align: center; margin-bottom: 2rem; }
        .header h1 { font-size: 2em; color: #00ff00; text-transform: uppercase; text-shadow: 0 0 5px #00ff00; }
        .header p { color: #ff0000; font-size: 1.2em; }
        .security-terminal { background: rgba(0, 0, 0, 0.8); border: 1px solid #00ffff; padding: 2rem; }
        .terminal-title { color: #00ffff; font-size: 1.5em; text-align: center; margin-bottom: 1.5rem; text-shadow: 0 0 5px #00ffff; }
        .form-group { margin-bottom: 1.5rem; }
        label { display: block; margin-bottom: 0.5rem; color: #00ffff; }
        input[type="text"] { width: 100%; padding: 0.8rem; background: rgba(0, 0, 0, 0.9); border: 1px solid #00ffff; color: #00ff00; font-family: 'Orbitron', sans-serif; transition: box-shadow 0.3s; }
        input[type="text"]:focus { outline: none; box-shadow: 0 0 15px #00ffff; }
        button { width: 100%; padding: 1rem; background: linear-gradient(45deg, #ff0000, #00ff00); border: none; color: white; font-family: 'Orbitron', sans-serif; font-size: 1.2em; cursor: pointer; transition: transform 0.3s; }
        button:hover { transform: scale(1.05); }
    </style>
</head>
<body>
    <div class="digital-rain"></div>
    <div class="security-bg"></div>
    <div class="container">
        <div class="header">
            <h1>Security Crew Chat: Iron Vault</h1>
            <p>Access Restricted—Prove Your Clearance</p>
        </div>
        <div class="security-terminal">
            <h2 class="terminal-title">Phase 1: Clearance Check</h2>
            <form action="security_check.php" method="POST" id="passForm">
                <div class="form-group">
                    <label for="input1">Teamcode:</label>
                    <input type="text" id="input1" name="input1" required placeholder="Enter first input...">
                </div>
                <div class="form-group">
                    <label for="input2">Passphrase:</label>
                    <input type="text" id="input2" name="input2" required placeholder="Enter second input...">
                </div>
                <button type="submit">Submit Clearance</button>
            </form>
            <?php include 'security_check.php'; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const rainContainer = document.querySelector('.digital-rain');
            const numberOfLines = 50;
            for (let i = 0; i < numberOfLines; i++) {
                const line = document.createElement('div');
                line.className = 'rain-line';
                line.style.left = `${Math.random() * 100}%`;
                line.style.animationDelay = `${Math.random() * 3}s`;
                rainContainer.appendChild(line);
            }
            console.log(atob('c2VjdXJpdHlfY2hlY2sucGhw')); // Hint: "security_check.php"
        });
    </script>
</body>
</html>
