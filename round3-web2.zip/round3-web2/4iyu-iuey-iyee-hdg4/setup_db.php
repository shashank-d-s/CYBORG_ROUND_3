<?php
// Create or connect to the SQLite database
$db = new SQLite3('level4.db');

// Drop existing tables for a clean setup
$db->exec('DROP TABLE IF EXISTS inner_circle_hackers');
$db->exec('DROP TABLE IF EXISTS chat_logs');
$db->exec('DROP TABLE IF EXISTS secrets');
$db->exec('DROP TABLE IF EXISTS dummy_config');

// Create core tables
$db->exec('CREATE TABLE inner_circle_hackers (id INTEGER PRIMARY KEY, h4ck3r_n4m3 TEXT NOT NULL, role TEXT NOT NULL)');
$db->exec("INSERT INTO inner_circle_hackers (id, h4ck3r_n4m3, role) VALUES 
    (1, 'VaultGuard', 'Enforcer'), (2, 'DarkOverlord', 'Leader'), (3, 'ZeroByte', 'Tech'), (4, 'CryptMaster', 'Crypto')");

$db->exec('CREATE TABLE chat_logs (message_id INTEGER PRIMARY KEY, user TEXT NOT NULL, content TEXT NOT NULL)');
$db->exec("INSERT INTO chat_logs (message_id, user, content) VALUES 
    (1, 'VaultGuard', 'Secure the perimeter'), (2, 'DarkOverlord', 'Intruder alert'), (3, 'ZeroByte', 'Lock it down')");

$db->exec('CREATE TABLE dummy_files (key_id INTEGER PRIMARY KEY, x7k9p TEXT NOT NULL)'); // Cryptic column name
$db->exec("INSERT INTO dummy_files (key_id, x7k9p) VALUES 
    (1, 'Perimeter codes: 1234'), (2, 'CYBORG{S3CU147R3LY_C23OMPL3T3D}'), (3, 'Encryption key: z9m8n')");

$db->exec('CREATE TABLE dummy_config (setting TEXT PRIMARY KEY, value TEXT NOT NULL)');
$db->exec("INSERT INTO dummy_config (setting, value) VALUES 
    ('firewall', 'enabled'), ('port', '1337'), ('debug', 'off')");

$dummy_tables = [
    'decoy1' => 'info', 'decoy2' => 'data', 'fake_logs' => 'log', 'shadow_ops' => 'op',
    'hidden1' => 'secret', 'hidden2' => 'code', 'sys_logs' => 'entry', 'backups' => 'backup',
    'crypto_vault' => 'key', 'noise1' => 'junk', 'noise2' => 'trash', 'red_herring' => 'flag',
    'ops_data' => 'status', 'dark_pool' => 'pool', 'echo_logs' => 'echo', 'phantom_data' => 'ghost',
    'vault_dummy' => 'vault', 'zero_logs' => 'zero', 'crypt_dummy' => 'crypt', 'neon_trap' => 'trap',
    'fake_secrets' => 'x7k9p', 'decoy_config' => 'setting', 'shadow_config' => 'value',
    'trap1' => 'data', 'trap2' => 'info', 'dummy_ops' => 'op'
];

foreach ($dummy_tables as $table => $column) {
    // ✅ Corrected column definition inside the query
    $db->exec("CREATE TABLE $table (
        id INTEGER PRIMARY KEY AUTOINCREMENT, 
        $column TEXT NOT NULL
    )");

    // ✅ Removed explicit `id` column from INSERT, SQLite auto-generates it
    $db->exec("INSERT INTO $table ($column) VALUES 
        ('Fake data 1'), ('Fake data 2'), ('FLAG{FAKE" . rand(1000, 9999) . "}')");
}

// Add misdirection in fake_secrets
$db->exec("INSERT INTO fake_secrets (id, x7k9p) VALUES (4, 'Not the real flag')");

// Close the database connection
$db->close();

echo "Database 'level4.db' created with 26 tables and populated successfully!";
?>
