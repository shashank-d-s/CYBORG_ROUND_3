<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['tran-member'])) {
        if ($_POST['tran-member'] === "yes") {
            // Redirect to the member page if "yes"
            header("Location: /2aku-ghfe-sdrf-iau2/");
            exit();
        } 
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Access Denied - Transaction Crew</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="noise"></div>
  <div class="container">
    <div class="access-denied">
      <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
      </svg>
      <h1>Access Denied</h1>
      <p>You are not a member of the Transaction Crew.</p>
      <p class="error-code">ERROR CODE: TC-401</p>
      <a href="index.html" class="back-link">Return to Main Chat</a>
    </div>
  </div>
</body>
</html>
