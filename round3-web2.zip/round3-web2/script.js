document.addEventListener('DOMContentLoaded', () => {
    const content = document.getElementById('content');
    const successMessage = document.getElementById('success-message');
    const errorMessage = document.getElementById('error-message');
    const loginForm = document.getElementById('login-form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');

    // Check for member cookie
    const hasMemberCookie = document.cookie
        .split('; ')
        .find(row => row.startsWith('is_member='))
        ?.split('=')[1] === 'true';

    if (hasMemberCookie) {
        content.classList.add('hidden');
        successMessage.classList.remove('hidden');
    } else {
        content.classList.remove('hidden');
        successMessage.classList.add('hidden');
    }

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = usernameInput.value;
        const password = passwordInput.value;

        if (username === 'recruit' && password === 'blackecho2024') {
            // Set cookie and show success message
            document.cookie = 'is_member=true;path=/';
            content.classList.add('hidden');
            successMessage.classList.remove('hidden');
            errorMessage.classList.add('hidden');
        } else {
            errorMessage.classList.remove('hidden');
            usernameInput.value = '';
            passwordInput.value = '';
            usernameInput.focus();
        }
    });

    // Submit form when Enter is pressed in password field
    passwordInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            loginForm.dispatchEvent(new Event('submit'));
        }
    });

    // Move to password field when Enter is pressed in username field
    usernameInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            passwordInput.focus();
        }
    });
});
